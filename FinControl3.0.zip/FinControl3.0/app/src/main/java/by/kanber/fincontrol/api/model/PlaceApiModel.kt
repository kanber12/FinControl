package by.kanber.fincontrol.api.model

import by.kanber.fincontrol.model.Place

data class PlaceApiModel(val id: Int, val name: String) {
    fun toPlace(): Place {
        return Place(id, name)
    }
}