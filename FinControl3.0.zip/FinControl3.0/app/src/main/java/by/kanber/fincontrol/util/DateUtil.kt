package by.kanber.fincontrol.util

import org.joda.time.DateTime
import org.joda.time.Months
import java.text.SimpleDateFormat
import java.util.*

class DateUtil {
    companion object {
        private val formatter =
            SimpleDateFormat("dd MM yyyy HH mm", Locale.US)

        fun getTime(time: Long): String {
            var result = ""
            var timeArray = timeToString(time).split(" ")
            var t: DateTime = DateTime(Date(time))
            return "today"
        }

        private fun timeToString(time: Long): String = formatter.format(Date(time))

        private fun isToday(currTime: DateTime, time: DateTime): Boolean =
            currTime.dayOfMonth == time.dayOfMonth && currTime.monthOfYear == time.monthOfYear && currTime.year == time.year

        private fun isYesterday(currTime: DateTime, time: DateTime): Boolean =
            currTime.year - time.year == 1 && currTime.dayOfMonth == 1 && time.dayOfMonth == 31 && currTime.monthOfYear == 1 && time.monthOfYear == 12 ||
                    currTime.year == time.year && currTime.monthOfYear - time.monthOfYear == 1 && currTime.dayOfMonth == 1 && time.dayOfMonth == getDaysInMonth(
                time.monthOfYear,
                time.year
            ) ||
                    currTime.year == time.year && currTime.monthOfYear == time.monthOfYear && currTime.dayOfMonth - time.dayOfMonth == 1

        private fun getDaysInMonth(month: Int, year: Int): Int =
            (28 + ((month + Math.floor(month / 8.0)) % 2) + 2 % month +
                    Math.floor((1 + (1 - (year % 4 + 2) % (year % 4 + 1)) * ((year % 100 + 2) % (year % 100 + 1.0)) + (1 - (year % 400 + 2) % (year % 400 + 1))) / month) +
                    Math.floor(1.0 / month) - Math.floor(((1 - (year % 4 + 2) % (year % 4 + 1)) * ((year % 100 + 2) % (year % 100 + 1)) + (1 - (year % 400 + 2) % (year % 400 + 1.0))) / month)).toInt()
    }
}