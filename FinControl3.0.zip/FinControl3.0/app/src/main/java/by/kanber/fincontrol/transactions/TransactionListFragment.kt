package by.kanber.fincontrol.transactions


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.content.ContextCompat
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.*
import android.widget.Toast

import by.kanber.fincontrol.R
import by.kanber.fincontrol.activity.MainActivity
import by.kanber.fincontrol.adapter.TransactionsAdapter
import by.kanber.fincontrol.api.model.TransactionApiModel
import by.kanber.fincontrol.base.BaseTransaction
import by.kanber.fincontrol.base.BaseView
import by.kanber.fincontrol.dialog.NavigationDrawerDialogFragment
import by.kanber.fincontrol.methods.PaymentMethodListFragment
import by.kanber.fincontrol.model.*
import by.kanber.fincontrol.util.Currency
import by.kanber.fincontrol.util.CustomItemDivider
import by.kanber.fincontrol.util.TransactionType
import kotlinx.android.synthetic.main.fragment_transaction_list.view.*
import retrofit2.HttpException

class TransactionListFragment : Fragment(), BaseView<TransactionApiModel> {
    private lateinit var recyclerView: RecyclerView
    private lateinit var transactions: MutableList<BaseTransaction>
    private lateinit var adapter: TransactionsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        initDataSet()
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_transaction_list, container, false)
        val manager = LinearLayoutManager(context)
        val divider = ContextCompat.getDrawable(context!!, R.drawable.list_item_divider)

        (activity as MainActivity).setSupportActionBar(view.trans_list_bap)

        recyclerView = view.trans_list_recycler_view
        view.trans_list_add_fab.setOnClickListener {
            showAddTransaction()
        }
        recyclerView.layoutManager = manager

        recyclerView.setHasFixedSize(true)
        recyclerView.addItemDecoration(
            CustomItemDivider(
                context,
                manager.orientation
            ).setDrawable(divider!!)
        )

        adapter = TransactionsAdapter(transactions)
        adapter.setOnTransactionClickListener(object :
            TransactionsAdapter.OnTransactionClickListener {
            override fun onClick(position: Int) {
                Toast.makeText(context, "Click", Toast.LENGTH_SHORT).show()
            }

            override fun onLingClick(position: Int) {
                Toast.makeText(context, "Long click", Toast.LENGTH_SHORT).show()
            }
        })

        recyclerView.adapter = adapter

        return view
    }

    override fun onCreateOptionsMenu(menu: Menu?, inflater: MenuInflater?) {
        inflater?.inflate(R.menu.transaction_list_menu, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item?.itemId) {
            R.id.menu_trans_list_show_methods -> showPaymentMethods()
            R.id.menu_trans_list_show_summary -> showStandardSummary()
            android.R.id.home -> showNavigationDrawer()
        }

        return true
    }

    private fun showNavigationDrawer() {
        val fragment = NavigationDrawerDialogFragment()
        fragment.setOnNavigationItemClickListener(object : NavigationDrawerDialogFragment.OnNavigationDrawerItemClickListener {
            override fun onItem1Click() {
                Toast.makeText(context, "Item 1", Toast.LENGTH_SHORT).show()
            }

            override fun onItem2Click() {
                Toast.makeText(context, "Item 2", Toast.LENGTH_SHORT).show()
            }

            override fun onItem3Click() {
                Toast.makeText(context, "Item 3", Toast.LENGTH_SHORT).show()
            }

            override fun onItem4Click() {
                Toast.makeText(context, "Item 4", Toast.LENGTH_SHORT).show()
            }

            override fun onItem5Click() {
                Toast.makeText(context, "Item 5", Toast.LENGTH_SHORT).show()
            }

            override fun onItem6Click() {
                Toast.makeText(context, "Item 6", Toast.LENGTH_SHORT).show()
            }

            override fun onItem7Click() {
                Toast.makeText(context, "Item 7", Toast.LENGTH_SHORT).show()
            }

            override fun onItem8Click() {
                Toast.makeText(context, "Item 8", Toast.LENGTH_SHORT).show()
            }

            override fun onItem9Click() {
                Toast.makeText(context, "Item 9", Toast.LENGTH_SHORT).show()
            }

            override fun onUserClick() {
                Toast.makeText(context, "User click", Toast.LENGTH_SHORT).show()
            }
        })

        fragment.show(activity?.supportFragmentManager, fragment.javaClass.name)
    }

    private fun showAddTransaction() {
        Toast.makeText(context, "Add transaction", Toast.LENGTH_SHORT).show()
    }

    private fun showPaymentMethods() {
        val trans = activity?.supportFragmentManager?.beginTransaction()
        val fragment = PaymentMethodListFragment()
        trans?.replace(R.id.fragment_container, fragment, fragment.javaClass.name)
        trans?.addToBackStack(fragment.javaClass.name)
        trans?.commit()
    }

    private fun showStandardSummary() {
        Toast.makeText(context, "Summary", Toast.LENGTH_SHORT).show()
    }

    private fun initDataSet() {
        val met1 = PaymentMethod(0, "Visa 6084", 240.0, Currency.BYN, false)
        val met2 = PaymentMethod(1, "Cash", 40.0, Currency.BYN, false)
        val met3 = PaymentMethod(2, "Visa 1234", 500.0, Currency.USD, false)
        val met4 = PaymentMethod(3, "Visa 9876", 1270.0, Currency.EUR, false)

        val place1 = Place(0, "Sosedi")
        val place2 = Place(1, "Green")
        val place3 = Place(2, "Transfer")
        val place4 = Place(3, "ATM")

        transactions = mutableListOf()
        transactions.add(
            ChargeOffTransaction(
                0,
                20.0,
                Currency.BYN,
                System.currentTimeMillis(),
                "Test note",
                TransactionType.CHARGE_OFF,
                met1,
                place1
            )
        )
        transactions.add(
            ChargeOffTransaction(
                0,
                10.0,
                Currency.USD,
                System.currentTimeMillis(),
                "",
                TransactionType.CHARGE_OFF,
                met2,
                place2
            )
        )
        transactions.add(
            RefillTransaction(
                0,
                100.0,
                Currency.BYN,
                System.currentTimeMillis(),
                "Perevod ot LExi",
                TransactionType.REFILL,
                place3,
                met1
            )
        )
        transactions.add(
            RefillTransaction(
                0,
                20.0,
                Currency.USD,
                System.currentTimeMillis(),
                "Some long text to check ellipsizing of text view with transaction note just for science purpose i hope that this is long enough. Cheer!",
                TransactionType.REFILL,
                place4,
                met3
            )
        )
        transactions.add(
            ChargeOffTransaction(
                0,
                2.0,
                Currency.BYN,
                System.currentTimeMillis(),
                "",
                TransactionType.CHARGE_OFF,
                met2,
                place1
            )
        )
        transactions.add(
            ChargeOffTransaction(
                0,
                54.0,
                Currency.EUR,
                System.currentTimeMillis(),
                "",
                TransactionType.CHARGE_OFF,
                met4,
                place2
            )
        )
        transactions.add(
            TransferTransaction(
                0,
                100.0,
                Currency.USD,
                System.currentTimeMillis(),
                "One more test note",
                TransactionType.TRANSFER,
                met3,
                met1
            )
        )
        transactions.add(
            TransferTransaction(
                0,
                5.0,
                Currency.BYN,
                System.currentTimeMillis(),
                "Yet another test note",
                TransactionType.TRANSFER,
                met1,
                met2
            )
        )
        transactions.add(
            RefillTransaction(
                0,
                200.0,
                Currency.USD,
                System.currentTimeMillis(),
                "",
                TransactionType.REFILL,
                place3,
                met3
            )
        )
        transactions.add(
            ChargeOffTransaction(
                0,
                120.0,
                Currency.BYN,
                System.currentTimeMillis(),
                "",
                TransactionType.CHARGE_OFF,
                met1,
                place2
            )
        )
        transactions.add(
            ChargeOffTransaction(
                0,
                5.0,
                Currency.USD,
                System.currentTimeMillis(),
                "Test note",
                TransactionType.CHARGE_OFF,
                met2,
                place1
            )
        )
        transactions.add(
            TransferTransaction(
                0,
                32.0,
                Currency.BYN,
                System.currentTimeMillis(),
                "Test note",
                TransactionType.TRANSFER,
                met1,
                met4
            )
        )
    }

    override fun onSuccessList(list: List<TransactionApiModel>) {

    }

    override fun onError(error: HttpException) {

    }
}
