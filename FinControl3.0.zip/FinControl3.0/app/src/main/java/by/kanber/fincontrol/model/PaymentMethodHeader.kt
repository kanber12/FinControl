package by.kanber.fincontrol.model

import by.kanber.fincontrol.base.PaymentMethodListItem

class PaymentMethodHeader : PaymentMethodListItem