package by.kanber.fincontrol.dialog

import android.app.Dialog
import android.os.Bundle
import android.support.v4.app.DialogFragment
import android.support.v7.app.AlertDialog
import android.widget.EditText
import android.widget.Toast
import by.kanber.fincontrol.R
import by.kanber.fincontrol.model.PaymentMethod
import by.kanber.fincontrol.util.Currency
import kotlinx.android.synthetic.main.fragment_add_method_dialog.view.*

class AddMethodDialogFragment : DialogFragment() {
    private lateinit var nameEditText: EditText
    private lateinit var balanceEditText: EditText
    private var listener: OnAddMethodFragmentInteractionListener? = null

    fun setOnAddMethodListener(listener: OnAddMethodFragmentInteractionListener) {
        this.listener = listener
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val builder = AlertDialog.Builder(context!!)
        val view = activity?.layoutInflater?.inflate(R.layout.fragment_add_method_dialog, null)!!

        nameEditText = view.add_method_name_edit_text
        balanceEditText = view.add_method_balance_edit_text

        builder.apply {
            setView(view)
            setPositiveButton("Add", null)
            setNegativeButton("Cancel", null)
        }

        val addDialog = builder.create()

        addDialog.setOnShowListener { dialog ->
            val posBtn = addDialog.getButton(Dialog.BUTTON_POSITIVE)

            posBtn.setOnClickListener {
                if (addMethod()) dialog.dismiss()
            }
        }

        isCancelable = false

        return addDialog
    }

    private fun addMethod(): Boolean {
        val name = nameEditText.text
        val balance = balanceEditText.text
        if (nameEditText.text.isEmpty()) {
            Toast.makeText(activity, "Enter name", Toast.LENGTH_SHORT).show()
            nameEditText.requestFocus()
        } else {
            if (balanceEditText.text.isEmpty()) {
                Toast.makeText(activity, "Enter balance", Toast.LENGTH_SHORT).show()
                balanceEditText.requestFocus()
            } else {
                listener?.addMethod(
                    createMethod(
                        name.toString(),
                        balance.toString().toDouble(),
                        false
                    )
                )

                return true
            }
        }

        return false
    }

    private fun createMethod(name: String, balance: Double, isDefault: Boolean): PaymentMethod {
        return PaymentMethod(name, balance, Currency.BYN, isDefault)
    }

    interface OnAddMethodFragmentInteractionListener {
        fun addMethod(method: PaymentMethod)
    }
}