package by.kanber.fincontrol.adapter

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import by.kanber.fincontrol.R
import by.kanber.fincontrol.base.PaymentMethodListItem
import by.kanber.fincontrol.model.PaymentMethod
import by.kanber.fincontrol.util.TextUtil
import com.bumptech.glide.Glide.init
import kotlinx.android.synthetic.main.method_list_item.view.*

class PaymentMethodsAdapter(private val methods: List<PaymentMethodListItem>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    val TYPE_HEADER = R.layout.method_list_item_add
    val TYPE_ITEM = R.layout.method_list_item
    var listener: OnMethodClickListener? = null

    fun setOnMethodClickListener(listener: OnMethodClickListener) {
        this.listener = listener
    }

    class HeaderViewHolder(v: View, listener: OnMethodClickListener?) : RecyclerView.ViewHolder(v) {
        init {
            v.setOnClickListener {
                listener?.onHeaderClick()
            }
        }
    }

    class ItemViewHolder(v: View, listener: OnMethodClickListener?) : RecyclerView.ViewHolder(v) {
        val nameTextView: TextView = v.method_name_text_view
        val balanceTextView: TextView = v.method_balance_text_view
        val defaultMarkHolder: FrameLayout = v.method_default_mark_holder

        init {
            v.setOnClickListener {
                if (adapterPosition != RecyclerView.NO_POSITION) {
                    listener?.onItemClick(adapterPosition)
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return when (viewType) {
            TYPE_ITEM -> ItemViewHolder(view, listener)
            else -> HeaderViewHolder(view, listener)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is ItemViewHolder) {
            val method = methods[position] as PaymentMethod
            holder.nameTextView.text = method.name
            holder.balanceTextView.text =
                TextUtil.getViewableBalance(method.balance, method.currency)

            holder.defaultMarkHolder.visibility = if (method.isDefault) View.VISIBLE else View.GONE
        }
    }

    override fun getItemCount(): Int = methods.size

    override fun getItemViewType(position: Int): Int = if (position == 0) TYPE_HEADER else TYPE_ITEM

    interface OnMethodClickListener {
        fun onItemClick(position: Int)
        fun onHeaderClick()
    }
}