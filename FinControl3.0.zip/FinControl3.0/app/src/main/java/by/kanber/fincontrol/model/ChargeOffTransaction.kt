package by.kanber.fincontrol.model

import by.kanber.fincontrol.base.BaseTransaction
import by.kanber.fincontrol.util.Currency
import by.kanber.fincontrol.util.TransactionType

class ChargeOffTransaction(
    id: Int,
    sum: Double,
    currency: Currency,
    date: Long,
    note: String,
    type: TransactionType,
    var fromMethod: PaymentMethod,
    var place: Place
) : BaseTransaction(id, sum, currency, date, note, type)