package by.kanber.fincontrol.util

enum class TransactionType {
    CHARGE_OFF,
    REFILL,
    TRANSFER
}