package by.kanber.fincontrol.transactions

import by.kanber.fincontrol.base.BasePresenter
import by.kanber.fincontrol.base.BaseTransaction
import by.kanber.fincontrol.base.BaseView

class TransactionListPresenter(baseView: BaseView<BaseTransaction>): BasePresenter<BaseTransaction>(baseView) {

}