package by.kanber.fincontrol.base

interface PaymentMethodListItem