package by.kanber.fincontrol.adapter

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import by.kanber.fincontrol.R
import by.kanber.fincontrol.base.BaseTransaction
import by.kanber.fincontrol.model.ChargeOffTransaction
import by.kanber.fincontrol.model.RefillTransaction
import by.kanber.fincontrol.model.TransferTransaction
import by.kanber.fincontrol.util.DateUtil
import by.kanber.fincontrol.util.TransactionType
import by.kanber.fincontrol.util.TextUtil
import kotlinx.android.synthetic.main.trans_list_item_charge_off.view.*
import kotlinx.android.synthetic.main.trans_list_item_refill.view.*
import kotlinx.android.synthetic.main.trans_list_item_transfer.view.*

class TransactionsAdapter(private val transactions: List<BaseTransaction>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    val TYPE_CHARGE_OFF = R.layout.trans_list_item_charge_off
    val TYPE_REFILL = R.layout.trans_list_item_refill
    val TYPE_TRANSFER = R.layout.trans_list_item_transfer
    var listener: OnTransactionClickListener? = null

    fun setOnTransactionClickListener(listener: OnTransactionClickListener) {
        this.listener = listener
    }

    abstract class TransactionViewHolder(v: View, listener: OnTransactionClickListener?) :
        RecyclerView.ViewHolder(v) {
        init {
            v.setOnClickListener {
                if (adapterPosition != RecyclerView.NO_POSITION) {
                    listener?.onClick(adapterPosition)
                }
            }

            v.setOnLongClickListener {
                if (adapterPosition != RecyclerView.NO_POSITION) {
                    listener?.onLingClick(adapterPosition)
                }

                true
            }
        }
    }

    class ChargeOffTransViewHolder(v: View, listener: OnTransactionClickListener?) :
        TransactionViewHolder(v, listener) {
        val sumTextView: TextView = v.trans_charge_off_sum_text_view
        val currencyTextView: TextView = v.trans_charge_off_currency_text_view
        val placeTextView: TextView = v.trans_charge_off_place_text_view
        val methodTextView: TextView = v.trans_charge_off_method_text_view
        val noteTextView: TextView = v.trans_charge_off_note_text_view
        val dateTextView: TextView = v.trans_charge_off_date_text_view
    }

    class RefillTransViewHolder(v: View, listener: OnTransactionClickListener?) :
        TransactionViewHolder(v, listener) {
        val sumTextView: TextView = v.trans_refill_sum_text_view
        val currencyTextView: TextView = v.trans_refill_currency_text_view
        val placeTextView: TextView = v.trans_refill_place_text_view
        val methodTextView: TextView = v.trans_refill_method_text_view
        val noteTextView: TextView = v.trans_refill_note_text_view
        val dateTextView: TextView = v.trans_refill_date_text_view
    }

    class TransferTransViewHolder(v: View, listener: OnTransactionClickListener?) :
        TransactionViewHolder(v, listener) {
        val sumTextView: TextView = v.trans_transfer_sum_text_view
        val currencyTextView: TextView = v.trans_transfer_currency_text_view
        val fromMethodTextView: TextView = v.trans_transfer_from_method_text_view
        val toMethodTextView: TextView = v.trans_transfer_to_method_text_view
        val noteTextView: TextView = v.trans_transfer_note_text_view
        val dateTextView: TextView = v.trans_transfer_date_text_view
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return when (viewType) {
            TYPE_CHARGE_OFF -> ChargeOffTransViewHolder(view, listener)
            TYPE_REFILL -> RefillTransViewHolder(view, listener)
            else -> TransferTransViewHolder(view, listener)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is ChargeOffTransViewHolder -> bindChargeOffHolder(
                holder,
                transactions[position] as ChargeOffTransaction
            )
            is RefillTransViewHolder -> bindRefillHolder(
                holder,
                transactions[position] as RefillTransaction
            )
            is TransferTransViewHolder -> bindTransferHolder(
                holder,
                transactions[position] as TransferTransaction
            )
        }
    }

    private fun bindChargeOffHolder(holder: ChargeOffTransViewHolder, trans: ChargeOffTransaction) {
        holder.sumTextView.text = TextUtil.getViewableSum(trans.sum)
        holder.currencyTextView.text = trans.currency.name
        holder.placeTextView.text = trans.place.name
        holder.methodTextView.text = TextUtil.getFromMethodName(trans.fromMethod.name)
        holder.dateTextView.text = DateUtil.getTime(trans.date)

        if (trans.note.isEmpty()) {
            holder.noteTextView.visibility = View.GONE
        } else {
            holder.noteTextView.visibility = View.VISIBLE
            holder.noteTextView.text = trans.note
        }
    }

    private fun bindRefillHolder(holder: RefillTransViewHolder, trans: RefillTransaction) {
        holder.sumTextView.text = TextUtil.getViewableSum(trans.sum)
        holder.currencyTextView.text = trans.currency.name
        holder.placeTextView.text = trans.place.name
        holder.methodTextView.text = TextUtil.getToMethodName(trans.toMethod.name)
        holder.dateTextView.text = DateUtil.getTime(trans.date)

        if (trans.note.isEmpty()) {
            holder.noteTextView.visibility = View.GONE
        } else {
            holder.noteTextView.visibility = View.VISIBLE
            holder.noteTextView.text = trans.note
        }
    }

    private fun bindTransferHolder(holder: TransferTransViewHolder, trans: TransferTransaction) {
        holder.sumTextView.text = TextUtil.getViewableSum(trans.sum)
        holder.currencyTextView.text = trans.currency.name
        holder.fromMethodTextView.text = TextUtil.getFromMethodName(trans.fromMethod.name)
        holder.toMethodTextView.text = TextUtil.getToMethodName(trans.toMethod.name)
        holder.dateTextView.text = DateUtil.getTime(trans.date)

        if (trans.note.isEmpty()) {
            holder.noteTextView.visibility = View.GONE
        } else {
            holder.noteTextView.visibility = View.VISIBLE
            holder.noteTextView.text = trans.note
        }
    }

    override fun getItemCount(): Int = transactions.size

    override fun getItemViewType(position: Int): Int {
        return when (transactions[position].type) {
            TransactionType.CHARGE_OFF -> TYPE_CHARGE_OFF
            TransactionType.REFILL -> TYPE_REFILL
            else -> TYPE_TRANSFER
        }
    }

    interface OnTransactionClickListener {
        fun onClick(position: Int)
        fun onLingClick(position: Int)
    }
}