package by.kanber.fincontrol.base

abstract class BasePresenter<I>(protected val baseView: BaseView<I>)