package by.kanber.fincontrol.model

import by.kanber.fincontrol.base.PaymentMethodListItem
import by.kanber.fincontrol.util.Currency

data class PaymentMethod(
    var name: String,
    var balance: Double,
    var currency: Currency,
    var isDefault: Boolean
) : PaymentMethodListItem {
    var id = 0

    constructor(
        id: Int,
        name: String,
        balance: Double,
        currency: Currency,
        isDefault: Boolean
    ) : this(name, balance, currency, isDefault) {
        this.id = id
    }
}