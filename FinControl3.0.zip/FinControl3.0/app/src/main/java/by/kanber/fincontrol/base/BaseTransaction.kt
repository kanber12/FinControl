package by.kanber.fincontrol.base

import by.kanber.fincontrol.util.Currency
import by.kanber.fincontrol.util.TransactionType

abstract class BaseTransaction(val id: Int, var sum: Double, var currency: Currency, var date: Long, var note: String, var type: TransactionType)