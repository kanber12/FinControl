package by.kanber.fincontrol.model

data class Place(val id: Int, val name: String)