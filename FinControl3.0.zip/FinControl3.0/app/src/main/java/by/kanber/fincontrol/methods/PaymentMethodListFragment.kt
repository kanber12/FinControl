package by.kanber.fincontrol.methods


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import by.kanber.fincontrol.R
import by.kanber.fincontrol.activity.MainActivity
import by.kanber.fincontrol.adapter.PaymentMethodsAdapter
import by.kanber.fincontrol.api.model.PaymentMethodApiModel
import by.kanber.fincontrol.base.BaseView
import by.kanber.fincontrol.base.PaymentMethodListItem
import by.kanber.fincontrol.dialog.AddMethodDialogFragment
import by.kanber.fincontrol.model.PaymentMethod
import by.kanber.fincontrol.model.PaymentMethodHeader
import by.kanber.fincontrol.util.Currency
import kotlinx.android.synthetic.main.fragment_payment_method_list.view.*
import kotlinx.android.synthetic.main.toolbar.view.*
import kotlinx.android.synthetic.main.toolbar_scrollable.view.*
import retrofit2.HttpException

class PaymentMethodListFragment : Fragment(), BaseView<PaymentMethodApiModel> {
    private lateinit var adapter: PaymentMethodsAdapter
    private lateinit var methods: MutableList<PaymentMethodListItem>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        initMethods()
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_payment_method_list, container, false)
        val toolbar = view.scrollable_toolbar

        toolbar.title = "Payment methods"
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back)
        (activity as MainActivity).setSupportActionBar(toolbar)
        toolbar.setNavigationOnClickListener {
            closeFragment()
        }

        val recyclerView = view.method_list_recycler_view
        recyclerView.setHasFixedSize(true)
        recyclerView.layoutManager = LinearLayoutManager(context)

        adapter = PaymentMethodsAdapter(methods)
        adapter.setOnMethodClickListener(object : PaymentMethodsAdapter.OnMethodClickListener {
            override fun onHeaderClick() {
                showAddMethodDialog()
            }

            override fun onItemClick(position: Int) {
                val method = methods[position] as PaymentMethod
                method.isDefault = !method.isDefault
                adapter.notifyItemChanged(position)
                Toast.makeText(context, method.name, Toast.LENGTH_SHORT).show()
            }
        })

        recyclerView.adapter = adapter

        return view
    }

    private fun closeFragment() {
        activity?.supportFragmentManager?.popBackStack()
        activity?.supportFragmentManager?.beginTransaction()?.remove(this)?.commit()
    }

    private fun initMethods() {
        methods = mutableListOf()
        methods.add(PaymentMethodHeader())
    }

    private fun showAddMethodDialog() {
        val fragment = AddMethodDialogFragment()
        fragment.setOnAddMethodListener(object : AddMethodDialogFragment.OnAddMethodFragmentInteractionListener {
            override fun addMethod(method: PaymentMethod) {
                methods.add(1, method)
                adapter.notifyItemInserted(1)
            }
        })

        fragment.show(activity?.supportFragmentManager, fragment.javaClass.name)
    }

    override fun onDeleteSuccess(code: Int, id: Int) {

    }

    override fun onSuccess(resp: PaymentMethodApiModel) {

    }

    override fun onSuccessList(list: List<PaymentMethodApiModel>) {

    }

    override fun onError(error: HttpException) {

    }
}
