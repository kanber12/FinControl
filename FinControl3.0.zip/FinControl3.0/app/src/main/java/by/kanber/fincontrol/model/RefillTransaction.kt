package by.kanber.fincontrol.model

import by.kanber.fincontrol.base.BaseTransaction
import by.kanber.fincontrol.util.Currency
import by.kanber.fincontrol.util.TransactionType

class RefillTransaction(
    id: Int,
    sum: Double,
    currency: Currency,
    date: Long,
    note: String,
    type: TransactionType,
    var place: Place,
    var toMethod: PaymentMethod
) : BaseTransaction(id, sum, currency, date, note, type)