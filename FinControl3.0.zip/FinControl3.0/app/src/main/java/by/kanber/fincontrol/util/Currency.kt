package by.kanber.fincontrol.util

enum class Currency {
    BYN,
    USD,
    EUR,
    RUB
}